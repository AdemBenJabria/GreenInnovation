import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AiRseService } from '../rseAI.service';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-rse-ai',
  standalone: true,
  imports: [CommonModule, FormsModule, NgClass],  // Added NgClass for handling dynamic classes
  templateUrl: './rse-ai.component.html',
  styleUrls: ['./rse-ai.component.scss']
})
export class RseAIComponent {
  userInput: string = '';
  chatMessages: any[] = [];
  presetQuestions: string[] = [
    'Comment améliorer notre impact environnemental?',
    'Quels sont les meilleurs pratiques pour le développement durable?',
    'Comment intégrer la RSE dans notre stratégie d’entreprise?'
  ];

  constructor(private aiRseService: AiRseService) {}

  sendMessage() {
    if (this.userInput.trim()) {
      this.chatMessages.push({ role: 'user', content: this.userInput });
      this.aiRseService.getResponse(this.userInput).subscribe(response => {
        this.chatMessages.push({ role: 'assistant', content: response.choices[0].message.content });
      });
      this.userInput = '';
    }
  }

  sendPresetQuestion(question: string) {
    this.userInput = question;
    this.sendMessage();
  }
}
